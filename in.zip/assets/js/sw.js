self.addEventListener('install', (event) => {
    console.log('Service Worker instalado');
  });
  
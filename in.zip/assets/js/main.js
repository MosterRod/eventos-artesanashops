
// Variables de apertura de icono
const iconChat = document.querySelector(".iconChat");

const activeMessage = setTimeout(function () {
    message.style.display = 'block'
}, 6000);



// Esta funcion es para hacer un toggle del icono del chatbot
function chat() {
  
    clearInterval(activeMessage);
    
    message.style.display = 'none';
    if (this.toggleAttribute('disable')) {
        this.setAttribute("src", `img/close-chat.png`);

    } else {
        this.setAttribute("src", `img/chat-icon.png`);

    }
    this.classList.toggle('btnTurn');
}


iconChat.addEventListener('click', chat);


  


        
            // Seleccionamos el elemento con la clase ghtml_description
            const descriptionElement = document.querySelector('.ghtml_description');
            const bigLetter = document.querySelector("#AA");
            const smallLetter = document.querySelector("#aA");

            // Inicializamos el tamaño de la fuente en 16px (puedes ajustarlo)
            let fontSize = 16;

            // Agregamos un evento 'click' al elemento
            bigLetter.addEventListener('click', function() {
                // Aumentamos el tamaño de la fuente en 2px cada vez que se hace clic
                fontSize += 2;
                // Aplicamos el nuevo tamaño de la fuente al elemento
                descriptionElement.style.fontSize = fontSize + 'px';
            });

            smallLetter.addEventListener('click', function() {
                // Aumentamos el tamaño de la fuente en 2px cada vez que se hace clic
                fontSize -= 2;
                // Aplicamos el nuevo tamaño de la fuente al elemento
                descriptionElement.style.fontSize = fontSize + 'px';
            });

            // Seleccionamos el elemento con el ID 'printer'
const printButton = document.getElementById('printer');

// Agregamos un evento 'click' para abrir el cuadro de impresión
printButton.addEventListener('click', function() {
    window.print(); // Esto abrirá el diálogo de impresión
});

// Compartir email 
document.getElementById('ghtmlMail').addEventListener('click', function() {
    const pageUrl = window.location.href;
    const title = document.querySelector('.ghtml_title').innerText; // Toma el texto del título
    const subject = encodeURIComponent('Revisa esta publicación');
    const body = encodeURIComponent(`Hola, quiero compartirte esta publicación: "${title}"\n\nPuedes verla aquí: ${pageUrl}`);
    
    window.location.href = `mailto:?subject=${subject}&body=${body}`;
});

// Compartir en WhatsApp
document.getElementById('ghtmlWhatsapp').addEventListener('click', function() {
    const pageUrl = window.location.href;
    const title = document.querySelector('.ghtml_title').innerText;
    const whatsappUrl = `https://api.whatsapp.com/send?text=${encodeURIComponent(title + ' ' + pageUrl)}`;
    window.open(whatsappUrl, '_blank');
});

// Compartir en Facebook
document.getElementById('ghtmlFb').addEventListener('click', function() {
    const pageUrl = window.location.href;
    const fbUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(pageUrl)}`;
    window.open(fbUrl, '_blank');
});

 

// Compartir en X (antes Twitter)
document.getElementById('ghtmlX').addEventListener('click', function() {
    const pageUrl = window.location.href;
    const title = document.querySelector('.ghtml_title').innerText;
    const xUrl = `https://twitter.com/intent/tweet?text=${encodeURIComponent(title + ' ' + pageUrl)}`;
    window.open(xUrl, '_blank');
});

document.getElementById('ghtmlCopy').addEventListener('click', function() {
    // Copiar enlace al portapapeles
    const pageUrl = window.location.href;
    navigator.clipboard.writeText(pageUrl).then(() => {
        // Crear el toast
        const toast = document.createElement('div');
        toast.innerText = "El enlace se ha copiado al portapapeles";
        
        // Estilos del toast
        const textCss = `
            position: fixed;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            background-color: black;
            color: white;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 14px;
            opacity: 0;
            transition: opacity 0.5s;
            z-index: 1000;
        `;
        
        // Aplicar estilos
        toast.style.cssText = textCss;

        // Agregar el toast al cuerpo del documento
        document.body.appendChild(toast);

        // Mostrar el toast
        setTimeout(() => {
            toast.style.opacity = '1';
        }, 100); // Ligerísimo retraso para la animación

        // Ocultar el toast después de 3 segundos y eliminarlo
        setTimeout(() => {
            toast.style.opacity = '0';
            setTimeout(() => {
                document.body.removeChild(toast);
            }, 500); // Esperar que la transición termine
        }, 3000); // Mostrar el toast durante 3 segundos
    }).catch(err => {
        console.error('Error al copiar el enlace: ', err);
    });
});

document.getElementById('share').addEventListener('click', function() {
    // Seleccionar la sección a la que se desea hacer scroll
    const section = document.getElementById('shareSection');
    
    // Desplazamiento suave hacia la sección
    section.scrollIntoView({
        behavior: 'smooth', // Hace el scroll suave
        block: 'start'      // Alinea el contenido al inicio de la vista
    });
});
  